#!/bin/bash

documento=$(date +%d_%m_%Y_)


for i in 'ls'/home/*; do

nombre=$(ls /home/ | grep -E [a-z][0-9]*)
espacio=$(cat | grep )

echo "$nombre" "$espacio" >> "$documento"espacio.txt

done

echo "LOS NOMBRES DE USUARIO Y SU CORRESPONDIENTE ESPACIO HAN SIDO ALMACENADOS EN UN FICHERO CON LA FECHA DE HOY"
